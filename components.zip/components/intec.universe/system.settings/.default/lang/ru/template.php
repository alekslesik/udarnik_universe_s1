<?php

$MESS['C_SYSTEM_SETTINGS_DEFAULT_BUTTONS_APPLY'] = 'Применить';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_BUTTONS_RESET'] = 'Сбросить настройки';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_SECTIONS_VARIANTS_NAME'] = 'Готовые вариации';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_SECTIONS_VARIANTS_DESCRIPTION'] = 'Здесь вы можете выбрать преднастроенный вариант под определенную сферу деятельности.';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_SECTIONS_PROPERTIES_NAME'] = 'Точная настройка';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_SECTIONS_PROPERTIES_DESCRIPTION'] = 'Здесь вы можете точечно управлять всеми разделами и блоками сайта, настраивать их внешний вид и последовательность, включать и отключать отдельные элементы.';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_SECTIONS_PROPERTIES_CATEGORIES_TEMPLATES'] = 'Конструктор';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_VIEWS_BLOCKS_TEMPLATES_TITLE'] = 'Вид отображения';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_VARIANTS_TITLE'] = 'Готовые решения';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_VARIANTS_VARIANT_SELECT'] = 'Выбрать';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_TEMPLATES_TITLE'] = 'Конструктор';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_TEMPLATES_TEMPLATE_EDIT'] = 'Редактировать';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_TEMPLATES_DESCRIPTION'] = '
    <p>Благодаря уникальному конструктору дизайна "intec.constructor" Вы сможете адаптировать интернет-магазин под индивидуальные задачи Вашего бизнеса - легко и просто, самостоятельно, без привлечения программистов и правки HTML-кода. </p>
    <p>Вы просто добавляете необходимые блоки и модули - отзывы, лид-формы, банеры и разделы каталога и перетаскиваете их по странице в нужное место.</p>
    <p>База готовых модулей и блоков включает более 50 элементов под решение самых разнообразных задач</p>
    <p>С помощью уникального конструктора Вы создадите свой неповторимый сайт, полностью соответствующий потребностями Вашего бизнеса и вашим предпочтениям в дизайне</p>
';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_PREFERENCES_HEADER'] = 'Выберите преднастроенный вариант оформления';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_PREFERENCES_RESET'] = 'Сделать как было';
$MESS['C_SYSTEM_SETTINGS_DEFAULT_PREFERENCES_BUTTON_CHOOSE'] = 'Выбрать';