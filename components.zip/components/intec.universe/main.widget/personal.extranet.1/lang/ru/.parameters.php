<?php

$MESS['C_PERSONAL_EXTRANET_TEMPLATE_1_PATH_TO_CRM'] = 'Адрес для Битрикс24';
