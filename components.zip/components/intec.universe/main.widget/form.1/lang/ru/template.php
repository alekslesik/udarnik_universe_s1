<?php

$MESS['C_WIDGET_TEMP_FORM1_ERROR'] = 'Ошибка при вызове компонента';