<?php

$MESS['C_FORM_RESULT_NEW_FORM1_CAPTCHA_TITLE'] = 'Введите проверочный код';
$MESS['C_FORM_RESULT_NEW_FORM1_CAPTCHA_PLACEHOLDER'] = 'Код картинки *';
$MESS['C_FORM_RESULT_NEW_FORM1_CONSENT_TEXT'] = 'Я согласен(а) на <a href="#URL#" target="_blank">обработку персональных данных</a>';