<?php

$MESS['C_MAIN_WIDGET_NAVIGATION_BUTTON_TOP_STUB'] = 'Кнопка "Наверх"';