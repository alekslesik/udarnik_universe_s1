<?php

$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_IBLOCK_TYPE'] = 'Тип инфоблока';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_IBLOCK_ID'] = 'Инфоблок';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_ELEMENT_ID_ENTER'] = 'Выбрать ID акции';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_ELEMENT_ID'] = 'ID акции';

$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_DISCOUNT_SHOW'] = 'Отображать скидку';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_PROPERTY_DISCOUNT'] = 'Свойство "скидка"';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_DISCOUNT_MINUS_USE'] = 'Скидка. Вставить "-" в начало строки';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_TIMER_SHOW'] = 'Отображать таймер (для работы необходимо указать дату начала и окончания активности)';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_TIMER_SECONDS_SHOW'] = 'Таймер. Отображать секунды';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_TIMER_END_HIDE'] = 'Скрыть таймер если время вышло';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_DATE_SHOW_FROM'] = 'Выводить дату акции';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_DATE_FROM_PROPERTY'] = 'из свойства';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_PROPERTY_DATE'] = 'Свойство "Дата проведения акции"';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_DATE_FROM_DATES'] = 'из даты начала активности и окончания активности';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_DATE_FORMAT'] = 'Формат даты';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_DATE_ONLY_ONE_SHOW'] = 'Выводить дату если нет даты окончания акции';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_TEXT_USE'] = 'Использовать текст';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_TEXT_USE_PREVIEW'] = 'анонса';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_TEXT_USE_DETAIL'] = 'детальный';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_ALL_TEXT_SHOW'] = 'Выводить весь текст';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_BUTTON_SHOW'] = 'Отображать кнопку перехода на детальный просмотр акции';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_BUTTON_TEXT'] = 'Кнопка. Текст кнопки';
$MESS['C_MAIN_WIDGET_CATALOG_SHARES_1_BUTTON_TEXT_DEFAULT'] = 'Условия акции';