<?php

$MESS['PRESETS_CONTACTS_1_PRESET_SIMPLE_1'] = 'Простой 1';
$MESS['PRESETS_CONTACTS_1_BLOCK_TITLE'] = 'Наши контакты';
$MESS['PRESETS_CONTACTS_1_FORM_TITLE'] = 'Заказать звонок';
$MESS['PRESETS_CONTACTS_1_FORM_BUTTON_TEXT'] = 'Заказать звонок';