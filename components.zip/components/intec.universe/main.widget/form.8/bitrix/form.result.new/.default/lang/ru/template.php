<?php

$MESS['C_FORM_RESULT_NEW_TEMPLATE_8_TEMPLATE_FIELDS_CAPTCHA'] = 'Введите проверочный код';
$MESS['C_FORM_RESULT_NEW_TEMPLATE_8_TEMPLATE_CONSENT'] = 'Я согласен(а) на <a href="#URL#" target="_blank">обработку персональных данных</a>';