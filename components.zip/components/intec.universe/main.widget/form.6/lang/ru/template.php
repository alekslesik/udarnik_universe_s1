<?php
$MESS['C_WIDGET_FORM_6_TITLE'] = 'Нужна консультация?';
$MESS['C_WIDGET_FORM_6_DESCRIPTION'] = 'Подробно расскажем о наших услугах, видах работ и типовых проектах, рассчитаем стоимость и подготовим индивидуальное предложение!';
$MESS['C_WIDGET_FORM_6_BUTTON_TEXT'] = 'Задать вопрос';
$MESS['C_WIDGET_FORM_6_FORM_TITLE'] = 'Задать вопрос';