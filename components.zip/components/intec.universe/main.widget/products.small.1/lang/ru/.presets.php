<?php

$MESS['PRESETS_PRODUCTS_SMALL_1_PRESET_TILES_3'] = 'Плитка 3';
$MESS['PRESETS_PRODUCTS_SMALL_1_PRESET_TILES_3_BIG'] = 'Плитка 3 с большим элементом';