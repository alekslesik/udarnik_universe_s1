<?php if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) die();

$arResult['WEB_FORM'] = CStartShopForm::GetByID($arParams['FORM_ID']);