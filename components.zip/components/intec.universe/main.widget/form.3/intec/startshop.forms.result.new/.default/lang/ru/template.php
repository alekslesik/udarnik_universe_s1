<?php

$MESS['C_WIDGET_FORM_3_WEB_FORM_CONSENT_TEXT_REPLACE'] = 'Я согласен(а) на <a href="#URL#" target="_blank">обработку персональных данных</a>';
$MESS['C_WIDGET_FORM_3_WEB_FORM_CAPTCHA_TITLE'] = 'Введите проверочный код';
$MESS['C_WIDGET_FORM_3_WEB_FORM_CAPTCHA_PLACEHOLDER'] = 'Код картинки *';

$MESS['C_WIDGET_FORM_3_WEB_FORM_ERROR_FORM_NOT_EXIST'] = 'Форма не существует';
$MESS['C_WIDGET_FORM_3_WEB_FORM_ERROR_FORM_UNBOUND'] = 'Форма не принадлежит к данному сайту';
$MESS['C_WIDGET_FORM_3_WEB_FORM_ERROR_FORM_NO_FIELDS'] = 'У формы нет полей';