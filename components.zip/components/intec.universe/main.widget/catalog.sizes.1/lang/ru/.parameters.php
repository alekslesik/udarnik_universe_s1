<?php

$MESS['C_MAIN_WIDGET_CATALOG_SIZES_1_PATH'] = 'Путь до файла таблицы стилей';