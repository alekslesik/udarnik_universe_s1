<?php
$MESS['C_WIDGET_FORM_4_TITLE'] = 'Нужна консультация?';
$MESS['C_WIDGET_FORM_4_DESCRIPTION'] = 'Подробно расскажем о наших услугах, видах работ и типовых проектах, рассчитаем стоимость и подготовим индивидуальное предложение!';
$MESS['C_WIDGET_FORM_4_BUTTON_TEXT'] = 'Задать вопрос';
$MESS['C_WIDGET_FORM_4_FORM_TITLE'] = 'Задать вопрос';