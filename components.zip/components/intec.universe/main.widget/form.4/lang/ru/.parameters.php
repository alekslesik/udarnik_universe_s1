<?php
$MESS['C_WIDGET_FORM_4_FORM_ID'] = 'Форма';
$MESS['C_WIDGET_FORM_4_FORM_TEMPLATE'] = 'Форма. Шаблон';
$MESS['C_WIDGET_FORM_4_FORM_TITLE'] = 'Форма. Текст заголовка';
$MESS['C_WIDGET_FORM_4_SETTINGS_USE'] = 'Использовать глобальные настройки';
$MESS['C_WIDGET_FORM_4_CONSENT_SHOW'] = 'Отображать согласие на обработку данных';
$MESS['C_WIDGET_FORM_4_CONSENT_URL'] = 'Соглашение на обработку данных. Ссылка на страницу';
$MESS['C_WIDGET_FORM_4_WIDE'] = 'Блок. На ширину экрана';
$MESS['C_WIDGET_FORM_4_BORDER_STYLE'] = 'Блок. Стиль границ';
$MESS['C_WIDGET_FORM_4_BORDER_STYLE_SQUARED'] = 'Прямые углы';
$MESS['C_WIDGET_FORM_4_BORDER_STYLE_ROUNDED'] = 'Скруглённые углы';
$MESS['C_WIDGET_FORM_4_TITLE'] = 'Блок. Заголовок';
$MESS['C_WIDGET_FORM_4_DESCRIPTION'] = 'Блок. Описание';
$MESS['C_WIDGET_FORM_4_BUTTON'] = 'Блок. Текст кнопки';
