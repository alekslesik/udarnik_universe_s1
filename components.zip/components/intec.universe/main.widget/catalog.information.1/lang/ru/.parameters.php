<?php

$MESS['C_MAIN_WIDGET_CATALOG_INFORMATION_1_PATH'] = 'Путь до файла таблицы стилей';